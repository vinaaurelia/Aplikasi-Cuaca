package com.android.cuaca.aplikasi_cuaca

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
