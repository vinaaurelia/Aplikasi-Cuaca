package com.example.aplikasi_cuaca

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
